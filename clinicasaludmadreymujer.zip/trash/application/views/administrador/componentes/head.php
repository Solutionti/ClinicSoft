<link  rel="icon"  href="<?php echo base_url(); ?>public/img/theme/logo2.ico" type="image/ico" />
<link id="pagestyle" href="<?php echo base_url(); ?>public/css/argon-dashboard.css?v=2.0.2" rel="stylesheet" />
<link href="<?php echo base_url(); ?>public/css/overhang.min.css" rel="stylesheet">
<link rel="stylesheet" href="<?php echo base_url(); ?>public/fontawesome/css/fontawesome.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>public/fontawesome/css/fontawesome.css">
<link href="<?php echo base_url(); ?>public/fontawesome/css/brands.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>public/fontawesome/css/solid.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>public/css/datatable.css" rel="stylesheet">
    