<?php
header('Content-Type: text/html; charset=UTF-8');
defined('BASEPATH') OR exit('No direct script access allowed');

class PdfController extends CI_Controller {

    private function fixText($texto) {
        return utf8_decode($texto);
    }

    
    public function __construct() {
        parent::__construct();
        $this->load->model('Ecografias_model'); // Cargar el modelo
    }

    public function getEcografiaMamaPdf($dni) {
      $datosPaciente = $this->Ecografias_model->getDatosPaciente($dni)->result()[0];
      $datosecografia = $this->Ecografias_model->getEcografiaMamaPdf($dni)->result()[0];

    $this->load->library('PDF_UTF8');
    $pdf = new PDF_UTF8();
    $pdf->AddPage();
    $pdf->SetAutoPageBreak(false);

    $pdf->SetAlpha(0.1); // Transparencia (0.1 = 10% opacidad)
    $pdf->Image("public/img/theme/logo.png", 70, 90, 120); // Ajusta las coordenadas y tamaño según necesites
    $pdf->SetAlpha(1); // Restauramos la opacidad al 100%
        
     // Barra lateral izquierda con imágenes
     $pdf->SetFillColor(230,230,230);
     $pdf->Rect(10, 10, 50, 277, 'F'); // Barra lateral gris
     
     // Imágenes en la barra lateral
     $pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
     $pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
     $pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);
     
     // Lista de ecografías en la barra lateral
    $pdf->SetFont('Arial', 'B', 8);
    $pdf->SetXY(15, 140); // Ajustamos la coordenada X de 12 a 15 para más margen
    $listado = array(
        "Ecografía Morfológica",
        "Ecografía Genética",
        "Ecografía Obstétrica",
        "Ecografía Obstétrica Doppler",
        "Ecografía Seguimiento ",
        "Ovulatorio",
        "Ecografía Transvaginal",
        "Ecografía Obstétrica",
        "Ecografía Gemelar",
        "Ecografía 3D, 4D, 5D",
        "Ecografía de Mamas",
        "OTRAS ECOGRAFÍAS",  
        "Ecografía Partes Blandas",
        "Ecografía Abdominal",
        "Ecografía Tiroides",
        "Ecografía Pélvica"
    );

    $tituloOtras = false;
    
    foreach($listado as $item) {
        if($item == "OTRAS ECOGRAFÍAS") {
            $pdf->SetFont('Arial', 'B', 8);
            $tituloOtras = true;
        } else if($tituloOtras) {
            $pdf->SetFont('Arial', '', 8);
        }
        
        if($item != "") {
            // Ajustamos el ancho de la celda y la alineación
            $pdf->Cell(50, 4, $item, 0, 1, 'L');
            // Reseteamos la posición X para la siguiente línea
            $pdf->SetX(15);
        } else {
            $pdf->Cell(50, 4, "", 0, 1, 'L');
            $pdf->SetX(15);
        }
    }

    $pdf->Ln(5);

    // Agregamos las dos nuevas imágenes después de toda la lista
    $pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
    $pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);

     // Título
     $pdf->SetFont('Arial', 'B', 14);
     $pdf->SetXY(70, 10);
     $pdf->Cell(130, 10, 'ECOGRAFÍA DE MAMA', 0, 1, 'C');
     
     // Información del paciente
     $pdf->SetFont('Arial', 'B', 10);
     $pdf->SetXY(70, 30);
     $pdf->Cell(30, 6, 'PACIENTE:', 0);
     $pdf->SetFont('Arial', '', 10);
     $pdf->Cell(100, 6, $datosPaciente->nombre . ' ' . $datosPaciente->apellido, 0);
     
     $pdf->SetXY(70, 36);
     $pdf->SetFont('Arial', 'B', 10);
     $pdf->Cell(30, 6, 'DNI:', 0);
     $pdf->SetFont('Arial', '', 10);
     $pdf->Cell(100, 6, $datosPaciente->documento, 0);
     
     $pdf->SetXY(70, 42);
     $pdf->SetFont('Arial', 'B', 10);
     $pdf->Cell(30, 6, 'EDAD:', 0);
     $pdf->SetFont('Arial', '', 10);
     $pdf->Cell(100, 6, $datosPaciente->edad . ' años', 0);
     
     $pdf->SetXY(70, 48);
     $pdf->SetFont('Arial', 'B', 10);
     $pdf->Cell(30, 6, 'FECHA:', 0);
     $pdf->SetFont('Arial', '', 10);
     $pdf->Cell(100, 6, $datosecografia->fecha, 0);
     
     $pdf->SetXY(70, 54);
     $pdf->SetFont('Arial', 'B', 10);
     $pdf->Cell(30, 6, 'MÉDICO:', 0);
     $pdf->SetFont('Arial', '', 10);
     $pdf->Cell(100, 6, $datosecografia->codigo_doctor, 0);
 
     // MAMA IZQUIERDA
     $pdf->SetXY(70, 70);
     $pdf->SetFont('Arial', 'B', 10);
     $pdf->Cell(130, 6, 'MAMA IZQUIERDA:', 0, 1);
     
     $pdf->SetXY(70, 80);
     $pdf->Cell(30, 6, 'Pezón:', 0);
     $pdf->SetFont('Arial', '', 10);
     $pdf->Cell(100, 6, $datosecografia->pezon_izq, 0);
    
    $pdf->SetXY(70, 86);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'TCSC:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosecografia->tcsc_izq, 0);
    
    $pdf->SetXY(70, 92);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'T. Glandular:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosecografia->tejido_glandular_izq, 0);
    
    $pdf->SetXY(70, 98);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'Axila:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosecografia->axila_izq, 0);

    // MAMA DERECHA
    $pdf->SetXY(70, 110);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(130, 6, 'MAMA DERECHA:', 0, 1);
    
    $pdf->SetXY(70, 120);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'Pezón:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosecografia->pezon_der, 0);
    
    $pdf->SetXY(70, 126);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'TCSC:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosecografia->tcsc_der, 0);
    
    $pdf->SetXY(70, 132);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'T. Glandular:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosecografia->tejido_glandular_der, 0);
    
    $pdf->SetXY(70, 138);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'Axila:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosecografia->axila_der, 0);

    // CONCLUSIÓN
    $pdf->SetXY(70, 150);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(130, 6, 'CONCLUSIÓN:', 0, 1);
    $pdf->SetXY(70, 156);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(130, 6, $datosecografia->conclusion_mama, 0);

    // SUGERENCIAS
    $pdf->SetXY(70, 180);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(130, 6, 'SUGERENCIAS:', 0, 1);
    $pdf->SetXY(70, 186);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(130, 6, $datosecografia->sugerencias_mama, 0);
 
     // Pie de página
     // Borde superior decorativo
     $pdf->SetFillColor(0,24,0); // Verde oscuro
     $pdf->Rect(10, 290, 190, 2, 'F');
 
     // Información de contacto
    // Lado izquierdo - Dirección
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(128,128,128); // Color gris para el texto
    $pdf->SetXY(60, 283);
    $pdf->Cell(100, 5, ('DIRECCIÓN: Av. Salaverry 1402 - Urb. Bancarios'), 0, 0, 'L');

    // Lado derecho - Celular e íconos
    $pdf->SetXY(140, 283);
    $pdf->Cell(30, 5, 'CELULAR: 902720312', 0, 0, 'R');
    
    // Íconos al lado del celular
    $pdf->Image("public/img/theme/facebook.png", 175, 283, 4, 4);
    $pdf->Image("public/img/theme/instagram.png", 182, 283, 4, 4);
    $pdf->Image("public/img/theme/wsp.jpeg", 189, 283, 4, 4);
 
     $pdf->Output('I', 'ecografia_mama.pdf');
     exit;
 }
//--------------------------------------------------------------------------------------------------------
public function getEcografiaGeneticaPdf($dni) {
    $datosPaciente = $this->Ecografias_model->getDatosPaciente($dni)->result()[0];
    $datosecografia = $this->Ecografias_model->getEcografiaGeneticaPdf($dni)->result()[0];

  $this->load->library('PDF_UTF8');
  $pdf = new PDF_UTF8();
  $pdf->AddPage();
  $pdf->SetAutoPageBreak(false);

// Marca de agua
    $pdf->SetAlpha(0.1);
    $pdf->Image("public/img/theme/logo.png", 70, 90, 120);
    $pdf->SetAlpha(1);

    // Barra lateral izquierda con imágenes
    $pdf->SetFillColor(230,230,230);
    $pdf->Rect(10, 5, 50, 277, 'F');
    
    // Imágenes en la barra lateral
    $pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
    $pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
    $pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);
    
    // Lista de ecografías en la barra lateral
    $pdf->SetFont('Arial', 'B', 8);
    $pdf->SetXY(15, 140);
    $listado = array(
        "Ecografía Morfológica",
        "Ecografía Genética",
        "Ecografía Obstétrica",
        "Ecografía Obstétrica Doppler",
        "Ecografía Seguimiento",
        "Ovulatorio",
        "Ecografía Transvaginal",
        "Ecografía Obstétrica – Dopple",
        "Ecografía Gemelar",
        "Ecografía 3D, 4D, 5D",
        "Ecografía de Mamas",
        "",
        "OTRAS ECOGRAFÍAS",
        "Ecografía Partes Blandas",
        "Ecografía Abdominal",
        "Ecografía Tiroides",
        "Ecografía Pélvica"
    );

    foreach($listado as $item) {
        $pdf->Cell(50, 4, $item, 0, 1, 'L');
        $pdf->SetX(15);
    }

    // Imágenes adicionales en la barra lateral
    $pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
    $pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);

    // Título
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->SetXY(70, 10);
    $pdf->Cell(130, 10, 'ECOGRAFÍA GENÉTICA', 0, 1, 'C');
    
    // Información del paciente
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->SetXY(70, 30);
    $pdf->Cell(30, 6, 'PACIENTE:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosPaciente->nombre . ' ' . $datosPaciente->apellido, 0);
    
    $pdf->SetXY(70, 36);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'DNI:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosPaciente->documento, 0);
    
    $pdf->SetXY(70, 42);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'EDAD:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosPaciente->edad . ' años', 0);
    
    $pdf->SetXY(70, 48);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'FECHA:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosecografia->fecha, 0);
    
    $pdf->SetXY(70, 54);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'MÉDICO:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosecografia->codigo_doctor, 0);

    // HALLAZGOS FETALES
    $pdf->SetXY(70, 70);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'HALLAZGOS FETALES:', 0, 1);
    
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->SetXY(70, 80);
    $pdf->Cell(50, 6, 'Feto/Embrión:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(80, 6, $datosecografia->fetoembrion, 0);

    $pdf->SetXY(70, 86);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(50, 6, 'Situación:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(80, 6, $datosecografia->situacion, 0);

    $pdf->SetXY(70, 92);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(50, 6, 'Líquido Amniótico:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(80, 6, $datosecografia->liquidoAmniotico, 0);

    // MEDICIONES
    $pdf->SetXY(70, 104);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'MEDICIONES:', 0, 1);

    $pdf->SetFont('Arial', 'B', 10);
    $pdf->SetXY(70, 114);
    $pdf->Cell(50, 6, 'Placenta:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(80, 6, $datosecografia->placenta . ' mm', 0);

    $pdf->SetXY(70, 120);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(50, 6, 'LCR:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(80, 6, $datosecografia->lcr . ' mm', 0);

    $pdf->SetXY(70, 126);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(50, 6, 'LCF:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(80, 6, $datosecografia->lcf . ' lpm', 0);

    // DOPPLER
    $pdf->SetXY(70, 138);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'ESTUDIO DOPPLER:', 0, 1);

    $pdf->SetFont('Arial', 'B', 10);
    $pdf->SetXY(70, 148);
    $pdf->Cell(50, 6, 'Art. Uterina Der:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(80, 6, $datosecografia->artUteder, 0);

    $pdf->SetXY(70, 154);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(50, 6, 'Art. Uterina Izq:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(80, 6, $datosecografia->artUteizq, 0);

    $pdf->SetXY(70, 160);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(50, 6, 'IP Promedio:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(80, 6, $datosecografia->ippromedio, 0);

    // MARCADORES
    $pdf->SetXY(70, 172);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'MARCADORES:', 0, 1);

    $pdf->SetFont('Arial', 'B', 10);
    $pdf->SetXY(70, 182);
    $pdf->Cell(50, 6, 'Hueso Nasal:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(80, 6, $datosecografia->huesoNasal, 0);

    $pdf->SetXY(70, 188);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(50, 6, 'Translucencia Nucal:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(80, 6, $datosecografia->translucenciaNucal . ' mm', 0);

    $pdf->SetXY(70, 194);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(50, 6, 'Ductus Venoso:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(80, 6, $datosecografia->ductudVenosa, 0);

    // CONCLUSIÓN Y SUGERENCIAS
    $pdf->SetXY(70, 206);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'CONCLUSIÓN:', 0, 1);
    $pdf->SetXY(70, 213);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(130, 6, $datosecografia->conclusion_mama, 0);

    $pdf->SetXY(70, 230);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'SUGERENCIAS:', 0, 1);
    $pdf->SetXY(70, 237);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(130, 6, $datosecografia->sugerencias_mama, 0);

    // Pie de página
     // Borde superior decorativo
     $pdf->SetFillColor(0,24,0); // Verde oscuro
     $pdf->Rect(10, 290, 190, 2, 'F');
 
     // Información de contacto
    // Lado izquierdo - Dirección
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(128,128,128); // Color gris para el texto
    $pdf->SetXY(60, 283);
    $pdf->Cell(100, 5, ('DIRECCIÓN: Av. Salaverry 1402 - Urb. Bancarios'), 0, 0, 'L');

    // Lado derecho - Celular e íconos
    $pdf->SetXY(140, 283);
    $pdf->Cell(30, 5, 'CELULAR: 902720312', 0, 0, 'R');
    
    // Íconos al lado del celular
    $pdf->Image("public/img/theme/facebook.png", 175, 283, 4, 4);
    $pdf->Image("public/img/theme/instagram.png", 182, 283, 4, 4);
    $pdf->Image("public/img/theme/wsp.jpeg", 189, 283, 4, 4);

    $pdf->Output('I', 'ecografia_genetica.pdf');
    exit;
}

//-------------------------------------------------------------------------------------------------------
public function getEcografiaMorfologicaPdf($dni) {
    $datosPaciente = $this->Ecografias_model->getDatosPaciente($dni)->result()[0];
    $datosecografia = $this->Ecografias_model->getEcografiaMorfologicaPdf($dni)->result()[0];

  $this->load->library('PDF_UTF8');
  $pdf = new PDF_UTF8();
  $pdf->AddPage();
  $pdf->SetAutoPageBreak(false);

// Marca de agua
$pdf->SetAlpha(0.1);
$pdf->Image("public/img/theme/logo.png", 70, 90, 120);
$pdf->SetAlpha(1);

// Barra lateral izquierda con imágenes
$pdf->SetFillColor(230,230,230);
$pdf->Rect(10, 5, 50, 277, 'F');

// Imágenes en la barra lateral
$pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
$pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
$pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);

// Lista de ecografías (igual que antes)
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetXY(15, 140);

$listado = array(
    "Ecografía Morfológica",
    "Ecografía Genética",
    "Ecografía Obstétrica",
    "Ecografía Obstétrica Doppler",
    "Ecografía Seguimiento",
    "Ovulatorio",
    "Ecografía Transvaginal",
    "Ecografía Obstétrica – Dopple",
    "Ecografía Gemelar",
    "Ecografía 3D, 4D, 5D",
    "Ecografía de Mamas",
    "",
    "OTRAS ECOGRAFÍAS",
    "Ecografía Partes Blandas",
    "Ecografía Abdominal",
    "Ecografía Tiroides",
    "Ecografía Pélvica"
);

foreach($listado as $item) {
    $pdf->Cell(50, 4, $item, 0, 1, 'L');
    $pdf->SetX(15);
}

// Imágenes adicionales en la barra lateral
$pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
$pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);

// Título
$pdf->SetFont('Arial', 'B', 14);
$pdf->SetXY(70, 10);
$pdf->Cell(130, 10, 'ECOGRAFÍA MORFOLÓGICA', 0, 1, 'C');

// Información del paciente
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 30);
$pdf->Cell(30, 6, 'PACIENTE:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->nombre . ' ' . $datosPaciente->apellido, 0);

$pdf->SetXY(70, 36);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'DNI:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->documento, 0);

$pdf->SetXY(70, 42);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'EDAD:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->edad . ' años', 0);

$pdf->SetXY(70, 48);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'FECHA:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->fecha, 0);

$pdf->SetXY(70, 54);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'MÉDICO:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->codigo_doctor, 0);

// EVALUACIÓN MORFOLÓGICA (comenzamos en 70)
$pdf->SetXY(70, 70);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'EVALUACIÓN MORFOLÓGICA:', 0, 1);

// Situación (a 80)
$pdf->SetXY(70, 80);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'Situación:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->situacion, 0);

// CABEZA Y SNC (a 90)
$pdf->SetXY(70, 90);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(130, 6, 'CABEZA Y SISTEMA NERVIOSO CENTRAL:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 97);
$pdf->MultiCell(130, 5, 'Forma y estructura: ' . $datosecografia->formacabeza, 0);

$pdf->SetXY(70, 107);
$pdf->Cell(60, 6, 'Cerebelo: ' . $datosecografia->cerebelo . ' mm', 0);
$pdf->SetXY(140, 107);
$pdf->Cell(60, 6, 'Cisterna Magna: ' . $datosecografia->cisternaMagna . ' mm', 0);

// CARA Y CUELLO (a 117)
$pdf->SetXY(70, 117);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(130, 6, 'CARA Y CUELLO:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 130);
$pdf->MultiCell(130, 5, 'Perfil facial: ' . $datosecografia->perfilCara, 0);

$pdf->SetXY(70, 125);
$pdf->MultiCell(130, 5, 'Cuello: ' . $datosecografia->cuello, 0);

// TÓRAX Y CORAZÓN (a 144)
$pdf->SetXY(70, 136);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(130, 6, 'TÓRAX Y CORAZÓN:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 142);
$pdf->MultiCell(130, 5, 'Perfil torácico: ' . ($datosecografia->perfiltorax), 0);

$pdf->SetXY(70, 147);
$pdf->MultiCell(130, 5, 'Evaluación cardíaca: ' . ($datosecografia->corazon), 0);

// ABDOMEN Y COLUMNA (a 176)
$pdf->SetXY(70, 165);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(130, 6, 'ABDOMEN Y COLUMNA VERTEBRAL:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 170);
$pdf->MultiCell(130, 5, 'Abdomen: ' . $datosecografia->abdomen, 0);

$pdf->SetXY(70, 185);
$pdf->MultiCell(130, 5, 'Columna vertebral: ' . $datosecografia->columnaVertebral, 0);

// BIOMETRÍA FETAL (a 208)
$pdf->SetXY(70, 190);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(160, 5, "BIOMETRÍA FETAL:", 0, 1, 'L');

$pdf->SetX(70);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(160, 5, "SEXO: " . $datosecografia->sexo, 0, 1, 'L');

// Datos biométricos (comenzando en 218)
$pdf->SetX(70);
$pdf->Cell(80, 5, "DBP: " . $datosecografia->dbp . " mm", 0, 0, 'L');
$pdf->Cell(80, 5, "CC: " . $datosecografia->cc . " mm", 0, 1, 'L');

$pdf->SetX(70);
$pdf->Cell(80, 5, "CA: " . $datosecografia->ca . " mm", 0, 0, 'L');
$pdf->Cell(80, 5, "LF: " . $datosecografia->lf . " mm", 0, 1, 'L');

$pdf->SetX(70);
$pdf->Cell(80, 5, "LCF: " . $datosecografia->lcf . " lpm", 0, 0, 'L');
$pdf->Cell(80, 5, "Peso estimado: " . $datosecografia->ponderadoFetal . " g", 0, 1, 'L');

// COMENTARIOS Y CONCLUSIONES (a 238)
$pdf->SetXY(70, 215);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(130, 6, 'COMENTARIOS:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 220);
$pdf->MultiCell(130, 5, $datosecografia->comentario, 0);

$pdf->SetXY(70, 232);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(130, 6, 'CONCLUSIONES:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 240);
$pdf->MultiCell(130, 5, $datosecografia->conclusiones, 0);


// Pie de página
     // Borde superior decorativo
     $pdf->SetFillColor(0,24,0); // Verde oscuro
     $pdf->Rect(10, 290, 190, 2, 'F');
 
     // Información de contacto
    // Lado izquierdo - Dirección
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(128,128,128); // Color gris para el texto
    $pdf->SetXY(60, 283);
    $pdf->Cell(100, 5, ('DIRECCIÓN: Av. Salaverry 1402 - Urb. Bancarios'), 0, 0, 'L');

    // Lado derecho - Celular e íconos
    $pdf->SetXY(140, 283);
    $pdf->Cell(30, 5, 'CELULAR: 902720312', 0, 0, 'R');
    
    // Íconos al lado del celular
    $pdf->Image("public/img/theme/facebook.png", 175, 283, 4, 4);
    $pdf->Image("public/img/theme/instagram.png", 182, 283, 4, 4);
    $pdf->Image("public/img/theme/wsp.jpeg", 189, 283, 4, 4);

$pdf->Output('I', 'ecografia_morfologica.pdf');
exit;

}

public function getEcografiaTrasvaginalPdf($dni) {
    $datosPaciente = $this->Ecografias_model->getDatosPaciente($dni)->result()[0];
    $datosecografia = $this->Ecografias_model->getEcografiaTrasvaginalPdf($dni)->result()[0]; 

  $this->load->library('PDF_UTF8');
  $pdf = new PDF_UTF8();
  $pdf->AddPage();
  $pdf->SetAutoPageBreak(false);

// Marca de agua
$pdf->SetAlpha(0.1);
$pdf->Image("public/img/theme/logo.png", 70, 90, 120);
$pdf->SetAlpha(1);

// Barra lateral izquierda con imágenes
$pdf->SetFillColor(230,230,230);
$pdf->Rect(10, 5, 50, 277, 'F');

// Imágenes en la barra lateral
$pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
$pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
$pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);

// Lista de ecografías (igual que antes)
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetXY(15, 140);

$listado = array(
    "Ecografía Morfológica",
    "Ecografía Genética",
    "Ecografía Obstétrica",
    "Ecografía Obstétrica Doppler",
    "Ecografía Seguimiento",
    "Ovulatorio",
    "Ecografía Transvaginal",
    "Ecografía Obstétrica – Dopple",
    "Ecografía Gemelar",
    "Ecografía 3D, 4D, 5D",
    "Ecografía de Mamas",
    "",
    "OTRAS ECOGRAFÍAS",
    "Ecografía Partes Blandas",
    "Ecografía Abdominal",
    "Ecografía Tiroides",
    "Ecografía Pélvica"
);

foreach($listado as $item) {
    $pdf->Cell(50, 4, $item, 0, 1, 'L');
    $pdf->SetX(15);
}

// Título
$pdf->SetFont('Arial', 'B', 14);
$pdf->SetXY(70, 10);
$pdf->Cell(130, 10, 'ECOGRAFIA TRASVAGINAL', 0, 1, 'C');

// Imágenes adicionales en la barra lateral
$pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
$pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);


// Información del paciente
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 30);
$pdf->Cell(30, 6, 'PACIENTE:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->nombre . ' ' . $datosPaciente->apellido, 0);

$pdf->SetXY(70, 36);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'DNI:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->documento, 0);

$pdf->SetXY(70, 42);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'EDAD:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->edad . ' años', 0);

$pdf->SetXY(70, 48);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'FECHA:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->fecha, 0);

$pdf->SetXY(70, 54);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'MÉDICO:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->codigo_doctor, 0);



// Información del paciente
// [código de información del paciente igual que antes]

// ÚTERO
$pdf->SetXY(70, 70);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'ÚTERO:', 0, 1);

$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 77);
$pdf->Cell(50, 6, 'Tipo:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->uteroTipo, 0);

$pdf->SetXY(70, 84);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Superficie:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->superficie, 0);

$pdf->SetXY(70, 91);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Medidas:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->uteroMedidas . ' x ' . $datosecografia->medidaUtero1 . ' x ' . $datosecografia->medidaUtero2 . ' mm', 0);

$pdf->SetXY(70, 98);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Miometrio:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->miometrio, 0);

$pdf->SetXY(70, 105);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Comentario:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(80, 6, $datosecografia->comentarioUtero, 0);

// ENDOMETRIO
$pdf->SetXY(70, 122);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'ENDOMETRIO:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 129);
$pdf->MultiCell(130, 5, $datosecografia->endometrio, 0);

// OVARIOS
$pdf->SetXY(70, 145);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'OVARIOS:', 0, 1);

// Ovario Derecho
$pdf->SetXY(70, 152);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Ovario Derecho:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->ovarioDer1 . ' x ' . $datosecografia->ovarioDer2 . ' mm', 0);

$pdf->SetXY(70, 159);
$pdf->MultiCell(130, 5, 'Comentario: ' . $datosecografia->comentarioOvarioDer, 0);

// Ovario Izquierdo
$pdf->SetXY(70, 171);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Ovario Izquierdo:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->ovarioIz1 . ' x ' . $datosecografia->ovarioIz2 . ' mm', 0);

$pdf->SetXY(70, 178);
$pdf->MultiCell(130, 5, 'Comentario: ' . $datosecografia->comentarioOvarioIzq, 0);

// OTROS HALLAZGOS
$pdf->SetXY(70, 190);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'OTROS HALLAZGOS:', 0, 1);

$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 197);
$pdf->Cell(50, 6, 'Fondo de Saco:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->fondosaco, 0);

$pdf->SetXY(70, 204);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Tumor Anexial:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(80, 6, $datosecografia->tumorAnexialCom, 0);

// CONCLUSIÓN Y SUGERENCIAS
$pdf->SetXY(70, 221);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'CONCLUSIÓN:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 228);
$pdf->MultiCell(130, 5, $datosecografia->conclusion, 0);

$pdf->SetXY(70, 245);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'SUGERENCIAS:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 252);
$pdf->MultiCell(130, 5, $datosecografia->sugerencias, 0);


// Pie de página
     // Borde superior decorativo
     $pdf->SetFillColor(0,24,0); // Verde oscuro
     $pdf->Rect(10, 290, 190, 2, 'F');
 
     // Información de contacto
    // Lado izquierdo - Dirección
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(128,128,128); // Color gris para el texto
    $pdf->SetXY(60, 283);
    $pdf->Cell(100, 5, ('DIRECCIÓN: Av. Salaverry 1402 - Urb. Bancarios'), 0, 0, 'L');

    // Lado derecho - Celular e íconos
    $pdf->SetXY(140, 283);
    $pdf->Cell(30, 5, 'CELULAR: 902720312', 0, 0, 'R');
    
    // Íconos al lado del celular
    $pdf->Image("public/img/theme/facebook.png", 175, 283, 4, 4);
    $pdf->Image("public/img/theme/instagram.png", 182, 283, 4, 4);
    $pdf->Image("public/img/theme/wsp.jpeg", 189, 283, 4, 4);

$pdf->Output('I', 'ecografia_trasvaginal.pdf');
exit;


}

public function getEcografiaPelvicaPdf($dni) {
    $datosPaciente = $this->Ecografias_model->getDatosPaciente($dni)->result()[0];
    $datosecografia = $this->Ecografias_model->getEcografiaPelvicaPdf($dni)->result()[0];

  $this->load->library('PDF_UTF8');
  $pdf = new PDF_UTF8();
  $pdf->AddPage();
  $pdf->SetAutoPageBreak(false);

  // Marca de agua
$pdf->SetAlpha(0.1);
$pdf->Image("public/img/theme/logo.png", 70, 90, 120);
$pdf->SetAlpha(1);

// Barra lateral izquierda con imágenes
$pdf->SetFillColor(230,230,230);
$pdf->Rect(10, 5, 50, 277, 'F');

// Imágenes en la barra lateral
$pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
$pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
$pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);

// Lista de ecografías (igual que antes)
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetXY(15, 140);

$listado = array(
    "Ecografía Morfológica",
    "Ecografía Genética",
    "Ecografía Obstétrica",
    "Ecografía Obstétrica Doppler",
    "Ecografía Seguimiento",
    "Ovulatorio",
    "Ecografía Transvaginal",
    "Ecografía Obstétrica – Dopple",
    "Ecografía Gemelar",
    "Ecografía 3D, 4D, 5D",
    "Ecografía de Mamas",
    "",
    "OTRAS ECOGRAFÍAS",
    "Ecografía Partes Blandas",
    "Ecografía Abdominal",
    "Ecografía Tiroides",
    "Ecografía Pélvica"
);

foreach($listado as $item) {
    $pdf->Cell(50, 4, $item, 0, 1, 'L');
    $pdf->SetX(15);
}


// Imágenes adicionales en la barra lateral
$pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
$pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);

  // Título
  $pdf->SetFont('Arial', 'B', 14);
  $pdf->SetXY(70, 10);
  $pdf->Cell(130, 10, ('ECOGRAFÍA PÉLVICA'), 0, 1, 'C');

// Información del paciente
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 30);
$pdf->Cell(30, 6, 'PACIENTE:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->nombre . ' ' . $datosPaciente->apellido, 0);

$pdf->SetXY(70, 36);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'DNI:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->documento, 0);

$pdf->SetXY(70, 42);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'EDAD:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->edad . ' años', 0);

$pdf->SetXY(70, 48);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'FECHA:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->fecha, 0);

$pdf->SetXY(70, 54);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'MÉDICO:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->codigo_doctor, 0);

// ÚTERO
$pdf->SetXY(70, 70);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, ('ÚTERO:'), 0, 1);

$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 77);
$pdf->Cell(50, 6, 'Tipo:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->utero_tipo, 0);

$pdf->SetXY(70, 84);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Superficie:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->superficie, 0);

$pdf->SetXY(70, 91);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Medidas:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->utero_medidas . ' x ' . $datosecografia->medida_utero1 . ' x ' . $datosecografia->medida_utero2 . ' mm', 0);

$pdf->SetXY(70, 98);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Miometrio:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->miometrio, 0);

$pdf->SetXY(70, 105);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Comentario:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(80, 6, $datosecografia->comentario_utero, 0);

// ENDOMETRIO
$pdf->SetXY(70, 122);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'ENDOMETRIO:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 129);
$pdf->MultiCell(130, 5, $datosecografia->endometrio, 0);

// OVARIOS
$pdf->SetXY(70, 145);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'OVARIOS:', 0, 1);

// Ovario Derecho
$pdf->SetXY(70, 152);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Ovario Derecho:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->ovario_der1 . ' x ' . $datosecografia->ovario_der2 . ' mm', 0);

$pdf->SetXY(70, 159);
$pdf->MultiCell(130, 5, 'Comentario: ' . $datosecografia->comentario_ovario_der, 0);

// Ovario Izquierdo
$pdf->SetXY(70, 171);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Ovario Izquierdo:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->ovario_iz1 . ' x ' . $datosecografia->ovario_iz2 . ' mm', 0);

$pdf->SetXY(70, 178);
$pdf->MultiCell(130, 5, 'Comentario: ' . $datosecografia->comentario_ovario_izq, 0);

// OTROS HALLAZGOS
$pdf->SetXY(70, 190);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'OTROS HALLAZGOS:', 0, 1);

$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 197);
$pdf->Cell(50, 6, 'Fondo de Saco:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->fondosaco, 0);

$pdf->SetXY(70, 204);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Tumor Anexial:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(80, 6, $datosecografia->tumor_anexial_com, 0);

// CONCLUSIÓN Y SUGERENCIAS
$pdf->SetXY(70, 221);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, $this->fixText('CONCLUSIÓN:'), 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 228);
$pdf->MultiCell(130, 5, $datosecografia->conclusion, 0);

$pdf->SetXY(70, 245);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'SUGERENCIAS:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 252);
$pdf->MultiCell(130, 5, $datosecografia->sugerencias, 0);


// Pie de página
     // Borde superior decorativo
     $pdf->SetFillColor(0,24,0); // Verde oscuro
     $pdf->Rect(10, 290, 190, 2, 'F');
 
     // Información de contacto
    // Lado izquierdo - Dirección
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(128,128,128); // Color gris para el texto
    $pdf->SetXY(60, 283);
    $pdf->Cell(100, 5, ('DIRECCIÓN: Av. Salaverry 1402 - Urb. Bancarios'), 0, 0, 'L');

    // Lado derecho - Celular e íconos
    $pdf->SetXY(140, 283);
    $pdf->Cell(30, 5, 'CELULAR: 902720312', 0, 0, 'R');
    
    // Íconos al lado del celular
    $pdf->Image("public/img/theme/facebook.png", 175, 283, 4, 4);
    $pdf->Image("public/img/theme/instagram.png", 182, 283, 4, 4);
    $pdf->Image("public/img/theme/wsp.jpeg", 189, 283, 4, 4);

$pdf->Output('I', 'ecografia_pelvica.pdf');
exit;


}

public function getEcografiaObstetricaPdf($dni) {
    $datosPaciente = $this->Ecografias_model->getDatosPaciente($dni)->result()[0];
    $datosecografia = $this->Ecografias_model->getEcografiaObstetricaPdf($dni)->result()[0]; 

  $this->load->library('PDF_UTF8');
  $pdf = new PDF_UTF8();
  $pdf->AddPage();
  $pdf->SetAutoPageBreak(false);

  // Marca de agua
$pdf->SetAlpha(0.1);
$pdf->Image("public/img/theme/logo.png", 70, 90, 120);
$pdf->SetAlpha(1);

// Barra lateral izquierda con imágenes
$pdf->SetFillColor(230,230,230);
$pdf->Rect(10, 5, 50, 277, 'F');

// Imágenes en la barra lateral
$pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
$pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
$pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);

// Lista de ecografías (igual que antes)
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetXY(15, 140);

$listado = array(
    "Ecografía Morfológica",
    "Ecografía Genética",
    "Ecografía Obstétrica",
    "Ecografía Obstétrica Doppler",
    "Ecografía Seguimiento",
    "Ovulatorio",
    "Ecografía Transvaginal",
    "Ecografía Obstétrica – Dopple",
    "Ecografía Gemelar",
    "Ecografía 3D, 4D, 5D",
    "Ecografía de Mamas",
    "",
    "OTRAS ECOGRAFÍAS",
    "Ecografía Partes Blandas",
    "Ecografía Abdominal",
    "Ecografía Tiroides",
    "Ecografía Pélvica"
);

foreach($listado as $item) {
    $pdf->Cell(50, 4, $item, 0, 1, 'L');
    $pdf->SetX(15);
}


// Imágenes adicionales en la barra lateral
$pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
$pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);


$pdf->SetFont('Arial', 'B', 14);
    $pdf->SetXY(70, 10);
    $pdf->Cell(130, 10, ('ECOGRAFÍA OBSTÉTRICA'), 0, 1, 'C');

// Información del paciente
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 30);
$pdf->Cell(30, 6, 'PACIENTE:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->nombre . ' ' . $datosPaciente->apellido, 0);

$pdf->SetXY(70, 36);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'DNI:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->documento, 0);

$pdf->SetXY(70, 42);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'EDAD:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->edad . ' años', 0);

$pdf->SetXY(70, 48);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'FECHA:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->fecha, 0);

$pdf->SetXY(70, 54);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'MÉDICO:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->codigo_doctor, 0);

// EVALUACIÓN FETAL
$pdf->SetXY(70, 70);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, ('EVALUACIÓN FETAL:'), 0, 1);

$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 77);
$pdf->Cell(50, 6, 'Feto/Embrión:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->fetoembrion, 0);

$pdf->SetXY(70, 84);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, ('Situación:'), 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->situacion, 0);

$pdf->SetXY(70, 91);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Estado Fetal:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(80, 6, $datosecografia->estadoFeto, 0);

// BIOMETRÍA FETAL
$pdf->SetXY(70, 110);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, ('BIOMETRÍA FETAL:'), 0, 1);

// Primera fila
$pdf->SetFont('Arial', '', 10);
$pdf->SetX(70);
$pdf->Cell(65, 6, 'DBP: ' . $datosecografia->dpb . ' mm', 0, 0, 'L');
$pdf->Cell(65, 6, 'CC: ' . $datosecografia->cc . ' mm', 0, 1, 'L');

// Segunda fila
$pdf->SetX(70);
$pdf->Cell(65, 6, 'CA: ' . $datosecografia->ca . ' mm', 0, 0, 'L');
$pdf->Cell(65, 6, 'LF: ' . $datosecografia->lf . ' mm', 0, 1, 'L');

// Tercera fila
$pdf->SetX(70);
$pdf->Cell(65, 6, 'LCF: ' . $datosecografia->lcf . ' lpm', 0, 0, 'L');
$pdf->Cell(65, 6, 'Minutos: ' . $datosecografia->min, 0, 1, 'L');

// OTROS HALLAZGOS
$pdf->SetXY(70, 140);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'OTROS HALLAZGOS:', 0, 1);

$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 147);
$pdf->Cell(50, 6, 'Placenta:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->placenta . ' mm', 0);

$pdf->SetXY(70, 154);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, ('Líquido Amniótico:'), 0);
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(80, 6, $datosecografia->ila, 0);

$pdf->SetXY(70, 167);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Percentil:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->percentil, 0);

// RECOMENDACIONES
$pdf->SetXY(70, 180);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'TIPO DE PARTO:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 187);
$pdf->MultiCell(130, 5, $datosecografia->tipoParto, 0);

// CONCLUSIÓN Y SUGERENCIAS
$pdf->SetXY(70, 200);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, ('CONCLUSIÓN:'), 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 207);
$pdf->MultiCell(130, 5, $datosecografia->conclusion, 0);

$pdf->SetXY(70, 225);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'SUGERENCIAS:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 232);
$pdf->MultiCell(130, 5, $datosecografia->sugerencia, 0);

// Pie de página
     // Borde superior decorativo
     $pdf->SetFillColor(0,24,0); // Verde oscuro
     $pdf->Rect(10, 290, 190, 2, 'F');
 
     // Información de contacto
    // Lado izquierdo - Dirección
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(128,128,128); // Color gris para el texto
    $pdf->SetXY(60, 283);
    $pdf->Cell(100, 5, ('DIRECCIÓN: Av. Salaverry 1402 - Urb. Bancarios'), 0, 0, 'L');

    // Lado derecho - Celular e íconos
    $pdf->SetXY(140, 283);
    $pdf->Cell(30, 5, 'CELULAR: 902720312', 0, 0, 'R');
    
    // Íconos al lado del celular
    $pdf->Image("public/img/theme/facebook.png", 175, 283, 4, 4);
    $pdf->Image("public/img/theme/instagram.png", 182, 283, 4, 4);
    $pdf->Image("public/img/theme/wsp.jpeg", 189, 283, 4, 4);

$pdf->Output('I', 'ecografia_obstetrica.pdf');
exit;

}

public function getEcografiaAbdominalPdf($dni) {
    $datosPaciente = $this->Ecografias_model->getDatosPaciente($dni)->result()[0];
    $datosecografia = $this->Ecografias_model->getEcografiaAbdominalPdf($dni)->result()[0]; 

  $this->load->library('PDF_UTF8');
  $pdf = new PDF_UTF8();
  $pdf->AddPage();
  $pdf->SetAutoPageBreak(false);

  // Marca de agua
$pdf->SetAlpha(0.1);
$pdf->Image("public/img/theme/logo.png", 70, 90, 120);
$pdf->SetAlpha(1);

// Barra lateral izquierda con imágenes
$pdf->SetFillColor(230,230,230);
$pdf->Rect(10, 5, 50, 277, 'F');

// Imágenes en la barra lateral
$pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
$pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
$pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);

// Lista de ecografías (igual que antes)
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetXY(15, 140);

$listado = array(
    "Ecografía Morfológica",
    "Ecografía Genética",
    "Ecografía Obstétrica",
    "Ecografía Obstétrica Doppler",
    "Ecografía Seguimiento",
    "Ovulatorio",
    "Ecografía Transvaginal",
    "Ecografía Obstétrica – Dopple",
    "Ecografía Gemelar",
    "Ecografía 3D, 4D, 5D",
    "Ecografía de Mamas",
    "",
    "OTRAS ECOGRAFÍAS",
    "Ecografía Partes Blandas",
    "Ecografía Abdominal",
    "Ecografía Tiroides",
    "Ecografía Pélvica"
);

foreach($listado as $item) {
    $pdf->Cell(50, 4, $item, 0, 1, 'L');
    $pdf->SetX(15);
}


// Imágenes adicionales en la barra lateral
$pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
$pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);


$pdf->SetFont('Arial', 'B', 14);
    $pdf->SetXY(70, 10);
    $pdf->Cell(130, 10, ('ECOGRAFÍA ABDOMINAL'), 0, 1, 'C');

// Información del paciente
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 30);
$pdf->Cell(30, 6, 'PACIENTE:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->nombre . ' ' . $datosPaciente->apellido, 0);

$pdf->SetXY(70, 36);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'DNI:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->documento, 0);

$pdf->SetXY(70, 42);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'EDAD:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->edad . ' años', 0);

$pdf->SetXY(70, 48);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'FECHA:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->fecha, 0);

$pdf->SetXY(70, 54);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'MÉDICO:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->codigo_doctor, 0);

// MOTIVO
$pdf->SetXY(70, 60);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'MOTIVO DE EXAMEN:', 0, 1);
$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 67);
$pdf->MultiCell(130, 5, $datosecografia->motivo, 0);

// HALLAZGOS
$pdf->SetXY(70, 80);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'HALLAZGOS:', 0, 1);

// Estómago
$pdf->SetXY(70, 87);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'ESTÓMAGO:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(80, 6, $datosecografia->estomago, 0);

// Hígado
$pdf->SetXY(70, 100);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'HÍGADO:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(80, 6, $datosecografia->higado, 0);

// Vesícula
$pdf->SetXY(70, 113);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(130, 6, 'VESÍCULA:', 0, 1);

$pdf->SetX(70);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(65, 6, 'Volumen: ' . $datosecografia->vesicula_volumen, 0, 1);
$pdf->SetX(70);
$pdf->Cell(65, 6, 'Paredes: ' . $datosecografia->vesicula_paredes, 0, 1);
$pdf->SetX(70);
$pdf->Cell(65, 6, 'Colédoco: ' . $datosecografia->coledoco_diametro . ' mm', 0, 1);

// Bazo
$pdf->SetXY(70, 138);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'BAZO:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->bazo, 0);

// Riñones
$pdf->SetXY(70, 150);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(130, 6, 'RIÑONES:', 0, 1);

$pdf->SetX(70);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(65, 6, 'Derecho: ' . $datosecografia->rinon_derecho, 0, 1);
$pdf->SetX(70);
$pdf->Cell(65, 6, 'Izquierdo: ' . $datosecografia->rinon_izquierdo, 0, 1);

// Otros Hallazgos
$pdf->SetXY(70, 170);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(130, 6, 'OTROS HALLAZGOS:', 0, 1);
$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 177);
$pdf->MultiCell(130, 5, $datosecografia->otros_hallazgos, 0);

// Conclusiones
$pdf->SetXY(70, 195);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'CONCLUSIONES:', 0, 1);
$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 202);
$pdf->MultiCell(130, 5, $datosecografia->conclusiones, 0);

// Sugerencias
$pdf->SetXY(70, 220);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'SUGERENCIAS:', 0, 1);
$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 227);
$pdf->MultiCell(130, 5, $datosecografia->sugerencias, 0);

// Pie de página
     // Borde superior decorativo
     $pdf->SetFillColor(0,24,0); // Verde oscuro
     $pdf->Rect(10, 290, 190, 2, 'F');
 
     // Información de contacto
    // Lado izquierdo - Dirección
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(128,128,128); // Color gris para el texto
    $pdf->SetXY(60, 283);
    $pdf->Cell(100, 5, ('DIRECCIÓN: Av. Salaverry 1402 - Urb. Bancarios'), 0, 0, 'L');

    // Lado derecho - Celular e íconos
    $pdf->SetXY(140, 283);
    $pdf->Cell(30, 5, 'CELULAR: 902720312', 0, 0, 'R');
    
    // Íconos al lado del celular
    $pdf->Image("public/img/theme/facebook.png", 175, 283, 4, 4);
    $pdf->Image("public/img/theme/instagram.png", 182, 283, 4, 4);
    $pdf->Image("public/img/theme/wsp.jpeg", 189, 283, 4, 4);

$pdf->Output('I', 'ecografia_abdominal.pdf');
exit;

}

public function getEcografiaProstaticaPdf($dni) {
    $datosPaciente = $this->Ecografias_model->getDatosPaciente($dni)->result()[0];
    $datosecografia = $this->Ecografias_model->getEcografiaProstaticaPdf($dni)->result()[0];  

  $this->load->library('PDF_UTF8');
  $pdf = new PDF_UTF8();
  $pdf->AddPage();
  $pdf->SetAutoPageBreak(false);

  // Marca de agua
$pdf->SetAlpha(0.1);
$pdf->Image("public/img/theme/logo.png", 70, 90, 120);
$pdf->SetAlpha(1);

// Barra lateral izquierda con imágenes
$pdf->SetFillColor(230,230,230);
$pdf->Rect(10, 5, 50, 277, 'F');

// Imágenes en la barra lateral
$pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
$pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
$pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);

// Lista de ecografías (igual que antes)
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetXY(15, 140);

$listado = array(
    "Ecografía Morfológica",
    "Ecografía Genética",
    "Ecografía Obstétrica",
    "Ecografía Obstétrica Doppler",
    "Ecografía Seguimiento",
    "Ovulatorio",
    "Ecografía Transvaginal",
    "Ecografía Obstétrica – Dopple",
    "Ecografía Gemelar",
    "Ecografía 3D, 4D, 5D",
    "Ecografía de Mamas",
    "",
    "OTRAS ECOGRAFÍAS",
    "Ecografía Partes Blandas",
    "Ecografía Abdominal",
    "Ecografía Tiroides",
    "Ecografía Pélvica"
);

foreach($listado as $item) {
    $pdf->Cell(50, 4, $item, 0, 1, 'L');
    $pdf->SetX(15);
}


// Imágenes adicionales en la barra lateral
$pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
$pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);


$pdf->SetFont('Arial', 'B', 14);
    $pdf->SetXY(70, 10);
    $pdf->Cell(130, 10, ('ECOGRAFÍA PROSTÁTICA'), 0, 1, 'C');

// Información del paciente
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 30);
$pdf->Cell(30, 6, 'PACIENTE:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->nombre . ' ' . $datosPaciente->apellido, 0);

$pdf->SetXY(70, 36);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'DNI:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->documento, 0);

$pdf->SetXY(70, 42);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'EDAD:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->edad . ' años', 0);

$pdf->SetXY(70, 48);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'FECHA:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->fecha, 0);

$pdf->SetXY(70, 54);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'MÉDICO:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->codigo_doctor, 0);

// MOTIVO
$pdf->SetXY(70, 60);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'MOTIVO DE EXAMEN:', 0, 1);
$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 67);
$pdf->MultiCell(130, 5, $datosecografia->motivo, 0);

// VEJIGA
$pdf->SetXY(70, 80);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'VEJIGA:', 0, 1);

$pdf->SetXY(70, 87);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Replicación:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->replicacion, 0);

$pdf->SetXY(70, 94);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Paredes:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->paredes, 0);

// Contenido
$pdf->SetXY(70, 101);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Contenido anecoico:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->contenido, 0);

if ($datosecografia->contenido == 'Sí') {
    $pdf->SetXY(70, 108);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(130, 5, 'Detalle: ' . $datosecografia->detalle_contenido, 0);
}

// Imágenes expansivas
$pdf->SetXY(70, 118);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Imágenes Expansivas:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->imagenes_expansivas, 0);

if ($datosecografia->imagenes_expansivas == 'Sí') {
    $pdf->SetXY(70, 125);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(130, 5, 'Detalle: ' . $datosecografia->detalle_imagenes, 0);
}

// Cálculos
$pdf->SetXY(70, 135);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Cálculos:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->calculos, 0);

if ($datosecografia->calculos == 'Sí') {
    $pdf->SetXY(70, 142);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(130, 5, 'Detalle: ' . $datosecografia->detalle_calculos, 0);
}

// Volúmenes
$pdf->SetXY(70, 152);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Vol. Pre-miccional:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->vol_pre . ' cc', 0);

$pdf->SetXY(70, 159);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Vol. Post-miccional:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->vol_post . ' cc', 0);

$pdf->SetXY(70, 166);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Retención:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->retencion . '%', 0);

// PRÓSTATA
$pdf->SetXY(70, 178);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'PRÓSTATA:', 0, 1);

$pdf->SetXY(70, 185);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Descripción:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(80, 6, $datosecografia->descripcion, 0);

$pdf->SetXY(70, 197);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Bordes:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->bordes, 0);

// Medidas próstata
$pdf->SetXY(70, 204);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Medidas:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, 'Transverso: ' . $datosecografia->transverso . ' mm', 0);

$pdf->SetXY(70, 211);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(130, 6, 'Anteroposterior: ' . $datosecografia->antero_posterior . ' mm', 0);

$pdf->SetXY(70, 218);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(130, 6, 'Longitudinal: ' . $datosecografia->longitudinal . ' mm', 0);

$pdf->SetXY(70, 225);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Volumen:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->volumen . ' cc', 0);

// Otras observaciones
if ($datosecografia->otra == 'Sí') {
    $pdf->SetXY(70, 232);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(50, 6, 'Otras Observaciones:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->MultiCell(80, 6, $datosecografia->observacion_textarea, 0);
}

// CONCLUSIONES
$pdf->SetXY(70, 245);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'CONCLUSIONES:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 252);
$pdf->MultiCell(130, 5, $datosecografia->conclusiones, 0);

// Pie de página
     // Borde superior decorativo
     $pdf->SetFillColor(0,24,0); // Verde oscuro
     $pdf->Rect(10, 290, 190, 2, 'F');
 
     // Información de contacto
    // Lado izquierdo - Dirección
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(128,128,128); // Color gris para el texto
    $pdf->SetXY(60, 283);
    $pdf->Cell(100, 5, ('DIRECCIÓN: Av. Salaverry 1402 - Urb. Bancarios'), 0, 0, 'L');

    // Lado derecho - Celular e íconos
    $pdf->SetXY(140, 283);
    $pdf->Cell(30, 5, 'CELULAR: 902720312', 0, 0, 'R');
    
    // Íconos al lado del celular
    $pdf->Image("public/img/theme/facebook.png", 175, 283, 4, 4);
    $pdf->Image("public/img/theme/instagram.png", 182, 283, 4, 4);
    $pdf->Image("public/img/theme/wsp.jpeg", 189, 283, 4, 4);

$pdf->Output('I', 'ecografia_prostatica.pdf');
exit;

}

public function getEcografiaRenalPdf($dni) {
    $datosPaciente = $this->Ecografias_model->getDatosPaciente($dni)->result()[0];
    $datosecografia = $this->Ecografias_model->getEcografiaRenalPdf($dni)->result()[0];

       //documentar esta linea para que genere el pdf 
       
       //print_r($datosPaciente);
      //echo "<br><br><br><br>";
     // print_r($datosecografia);
    //   

  $this->load->library('PDF_UTF8');
  $pdf = new PDF_UTF8();
  $pdf->AddPage();
  $pdf->SetAutoPageBreak(false);

  // Marca de agua
$pdf->SetAlpha(0.1);
$pdf->Image("public/img/theme/logo.png", 70, 90, 120);
$pdf->SetAlpha(1);

// Barra lateral izquierda con imágenes
$pdf->SetFillColor(230,230,230);
$pdf->Rect(10, 5, 50, 277, 'F');

// Imágenes en la barra lateral
$pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
$pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
$pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);

// Lista de ecografías (igual que antes)
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetXY(15, 140);

$listado = array(
    "Ecografía Morfológica",
    "Ecografía Genética",
    "Ecografía Obstétrica",
    "Ecografía Obstétrica Doppler",
    "Ecografía Seguimiento",
    "Ovulatorio",
    "Ecografía Transvaginal",
    "Ecografía Obstétrica – Dopple",
    "Ecografía Gemelar",
    "Ecografía 3D, 4D, 5D",
    "Ecografía de Mamas",
    "",
    "OTRAS ECOGRAFÍAS",
    "Ecografía Partes Blandas",
    "Ecografía Abdominal",
    "Ecografía Tiroides",
    "Ecografía Pélvica"
);

foreach($listado as $item) {
    $pdf->Cell(50, 4, $item, 0, 1, 'L');
    $pdf->SetX(15);
}


// Imágenes adicionales en la barra lateral
$pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
$pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);


$pdf->SetFont('Arial', 'B', 14);
    $pdf->SetXY(70, 10);
    $pdf->Cell(130, 10, ('ECOGRAFÍA RENAL'), 0, 1, 'C');

// Información del paciente
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 30);
$pdf->Cell(30, 6, 'PACIENTE:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->nombre . ' ' . $datosPaciente->apellido, 0);

$pdf->SetXY(70, 36);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'DNI:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->documento, 0);

$pdf->SetXY(70, 42);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'EDAD:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->edad . ' años', 0);

$pdf->SetXY(70, 48);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'FECHA:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->fecha, 0);

$pdf->SetXY(70, 54);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'MÉDICO:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->codigo_doctor, 0);

 // MOTIVO
 $pdf->SetXY(70, 60);
 $pdf->SetFont('Arial', 'B', 11);
 $pdf->Cell(130, 6, 'MOTIVO DE EXAMEN:', 0, 1);
 $pdf->SetFont('Arial', '', 10);
 $pdf->SetXY(70, 67);
 $pdf->MultiCell(130, 5, $datosecografia->motivo, 0);

 // RIÑÓN DERECHO
 $pdf->SetXY(70, 80);
 $pdf->SetFont('Arial', 'B', 11);
 $pdf->Cell(130, 6, 'RIÑÓN DERECHO:', 0, 1);

 $pdf->SetXY(70, 87);
 $pdf->SetFont('Arial', 'B', 10);
 $pdf->Cell(50, 6, 'Morfología y Movilidad:', 0);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(80, 6, $datosecografia->morfologia_movilidad_derecho, 0);

 $pdf->SetXY(70, 94);
 $pdf->SetFont('Arial', 'B', 10);
 $pdf->Cell(50, 6, 'Ecogenicidad:', 0);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(80, 6, $datosecografia->ecogenicidad_derecho, 0);

 $pdf->SetXY(70, 101);
 $pdf->SetFont('Arial', 'B', 10);
 $pdf->Cell(50, 6, 'Medidas:', 0);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(80, 6, $datosecografia->medidas_longitud_derecho, 0);

 $pdf->SetXY(70, 108);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(130, 6, $datosecografia->medidas_parenquima_derecho, 0);

 // Imágenes expansivas riñón derecho
 $pdf->SetXY(70, 115);
 $pdf->SetFont('Arial', 'B', 10);
 $pdf->Cell(50, 6, 'Imágenes Expansivas:', 0);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(40, 6, 'Sólidas: ' . $datosecografia->imagenes_expansivas_solidas_derecho, 0);
 $pdf->Cell(40, 6, 'Quísticas: ' . $datosecografia->imagenes_expansivas_quisticas_derecho, 0);

 // Hidronefrosis riñón derecho
 $pdf->SetXY(70, 122);
 $pdf->SetFont('Arial', 'B', 10);
 $pdf->Cell(50, 6, 'Hidronefrosis:', 0);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(80, 6, $datosecografia->hidronefrosis_derecho, 0);

 if (!empty($datosecografia->medidas_hidronefrosis_derecho)) {
     $pdf->SetXY(70, 129);
     $pdf->SetFont('Arial', '', 10);
     $pdf->Cell(130, 6, 'Medidas: ' . $datosecografia->medidas_hidronefrosis_derecho, 0);
 }

 // RIÑÓN IZQUIERDO
 $pdf->SetXY(70, 140);
 $pdf->SetFont('Arial', 'B', 11);
 $pdf->Cell(130, 6, 'RIÑÓN IZQUIERDO:', 0, 1);

 $pdf->SetXY(70, 147);
 $pdf->SetFont('Arial', 'B', 10);
 $pdf->Cell(50, 6, 'Morfología y Movilidad:', 0);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(80, 6, $datosecografia->morfologia_movilidad_izquierdo, 0);

 $pdf->SetXY(70, 154);
 $pdf->SetFont('Arial', 'B', 10);
 $pdf->Cell(50, 6, 'Ecogenicidad:', 0);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(80, 6, $datosecografia->ecogenicidad_izquierdo, 0);

 $pdf->SetXY(70, 161);
 $pdf->SetFont('Arial', 'B', 10);
 $pdf->Cell(50, 6, 'Medidas:', 0);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(80, 6, $datosecografia->medidas_longitud_izquierdo, 0);

 $pdf->SetXY(70, 168);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(130, 6, $datosecografia->medidas_parenquima_izquierdo, 0);

 // Imágenes expansivas riñón izquierdo
 $pdf->SetXY(70, 175);
 $pdf->SetFont('Arial', 'B', 10);
 $pdf->Cell(50, 6, 'Imágenes Expansivas:', 0);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(40, 6, 'Sólidas: ' . $datosecografia->imagenes_expansivas_solidas_izquierdo, 0);
 $pdf->Cell(40, 6, 'Quísticas: ' . $datosecografia->imagenes_expansivas_quisticas_izquierdo, 0);

 // Hidronefrosis riñón izquierdo
 $pdf->SetXY(70, 182);
 $pdf->SetFont('Arial', 'B', 10);
 $pdf->Cell(50, 6, 'Hidronefrosis:', 0);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(80, 6, $datosecografia->hidronefrosis_izquierdo, 0);

 if (!empty($datosecografia->medidas_hidronefrosis_izquierdo)) {
     $pdf->SetXY(70, 189);
     $pdf->SetFont('Arial', '', 10);
     $pdf->Cell(130, 6, 'Medidas: ' . $datosecografia->medidas_hidronefrosis_izquierdo, 0);
 }

 // VEJIGA
$pdf->SetXY(70, 200);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'VEJIGA:', 0, 1);

// Primera columna
$pdf->SetXY(70, 207);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 6, 'Repleción:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(25, 6, $datosecografia->repelcion_vejiga, 0);

// Segunda columna
$pdf->SetXY(135, 207);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 6, 'Vol. Pre-miccional:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(25, 6, $datosecografia->vol_pre_miccional . ' cc', 0);

// Primera columna
$pdf->SetXY(70, 214);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 6, 'Paredes:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(25, 6, $datosecografia->paredes_vejiga, 0);

// Segunda columna
$pdf->SetXY(135, 214);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 6, 'Vol. Post-miccional:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(25, 6, $datosecografia->vol_post_miccional . ' cc', 0);

// Primera columna
$pdf->SetXY(70, 221);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 6, 'Contenido:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(25, 6, $datosecografia->contenido_aneocoico, 0);

// Segunda columna
$pdf->SetXY(135, 221);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 6, 'Retención:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(25, 6, $datosecografia->retencion . '%', 0);

// Primera columna
$pdf->SetXY(70, 228);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 6, 'Imágenes Expansivas:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(25, 6, $datosecografia->imagenes_expansivas_vejiga, 0);

// Primera columna
$pdf->SetXY(70, 235);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 6, 'Cálculos:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(25, 6, $datosecografia->calculos_vejiga, 0);

 // Volúmenes
 $pdf->SetXY(70, 242);
 $pdf->SetFont('Arial', 'B', 10);
 $pdf->Cell(50, 6, 'Vol. Pre-miccional:', 0);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(80, 6, $datosecografia->vol_pre_miccional . ' cc', 0);

 $pdf->SetXY(70, 249);
 $pdf->SetFont('Arial', 'B', 10);
 $pdf->Cell(50, 6, 'Vol. Post-miccional:', 0);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(80, 6, $datosecografia->vol_post_miccional . ' cc', 0);

 $pdf->SetXY(70, 256);
 $pdf->SetFont('Arial', 'B', 10);
 $pdf->Cell(50, 6, 'Retención:', 0);
 $pdf->SetFont('Arial', '', 10);
 $pdf->Cell(80, 6, $datosecografia->retencion . '%', 0);

 // Nueva página para conclusiones
 $pdf->AddPage();
 
 // Marca de agua en la segunda página
$pdf->SetAlpha(0.1);
$pdf->Image("public/img/theme/logo.png", 70, 90, 120);
$pdf->SetAlpha(1);

// Barra lateral izquierda con imágenes en la segunda página
$pdf->SetFillColor(230,230,230);
$pdf->Rect(10, 5, 50, 277, 'F');

// Imágenes en la barra lateral de la segunda página
$pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
$pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
$pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);

// Lista de ecografías en la segunda página
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetXY(15, 140);
foreach($listado as $item) {
    $pdf->Cell(50, 4, $item, 0, 1, 'L');
    $pdf->SetX(15);
}

// Imágenes adicionales en la barra lateral de la segunda página
$pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
$pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);

 // Otras observaciones
 if (!empty($datosecografia->observacion_textarea)) {
     $pdf->SetXY(70, 30);
     $pdf->SetFont('Arial', 'B', 11);
     $pdf->Cell(130, 6, 'OTRAS OBSERVACIONES:', 0, 1);
     $pdf->SetFont('Arial', '', 10);
     $pdf->SetXY(70, 37);
     $pdf->MultiCell(130, 5, $datosecografia->observacion_textarea, 0);
 }

 // CONCLUSIONES
 $pdf->SetXY(70, 60);
 $pdf->SetFont('Arial', 'B', 11);
 $pdf->Cell(130, 6, 'CONCLUSIONES:', 0, 1);
 
 $pdf->SetFont('Arial', '', 10);
 $pdf->SetXY(70, 67);
 $pdf->MultiCell(130, 5, $datosecografia->conclusiones, 0);

// Pie de página
     // Borde superior decorativo
     $pdf->SetFillColor(0,24,0); // Verde oscuro
     $pdf->Rect(10, 290, 190, 2, 'F');
 
     // Información de contacto
    // Lado izquierdo - Dirección
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(128,128,128); // Color gris para el texto
    $pdf->SetXY(60, 283);
    $pdf->Cell(100, 5, ('DIRECCIÓN: Av. Salaverry 1402 - Urb. Bancarios'), 0, 0, 'L');

    // Lado derecho - Celular e íconos
    $pdf->SetXY(140, 283);
    $pdf->Cell(30, 5, 'CELULAR: 902720312', 0, 0, 'R');
    
    // Íconos al lado del celular
    $pdf->Image("public/img/theme/facebook.png", 175, 283, 4, 4);
    $pdf->Image("public/img/theme/instagram.png", 182, 283, 4, 4);
    $pdf->Image("public/img/theme/wsp.jpeg", 189, 283, 4, 4);

$pdf->Output('I', 'ecografia_renal.pdf');
exit;

}


public function getEcografiaTiroidesPdf($dni) {
    $datosPaciente = $this->Ecografias_model->getDatosPaciente($dni)->result()[0];
    $datosecografia = $this->Ecografias_model->getEcografiaTiroidesPdf($dni)->result()[0]; 

  $this->load->library('PDF_UTF8');
  $pdf = new PDF_UTF8();
  $pdf->AddPage();
  $pdf->SetAutoPageBreak(false);

  // Marca de agua
$pdf->SetAlpha(0.1);
$pdf->Image("public/img/theme/logo.png", 70, 90, 120);
$pdf->SetAlpha(1);

// Barra lateral izquierda con imágenes
$pdf->SetFillColor(230,230,230);
$pdf->Rect(10, 5, 50, 277, 'F');

// Imágenes en la barra lateral
$pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
$pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
$pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);

// Lista de ecografías (igual que antes)
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetXY(15, 140);

$listado = array(
    "Ecografía Morfológica",
    "Ecografía Genética",
    "Ecografía Obstétrica",
    "Ecografía Obstétrica Doppler",
    "Ecografía Seguimiento",
    "Ovulatorio",
    "Ecografía Transvaginal",
    "Ecografía Obstétrica – Dopple",
    "Ecografía Gemelar",
    "Ecografía 3D, 4D, 5D",
    "Ecografía de Mamas",
    "",
    "OTRAS ECOGRAFÍAS",
    "Ecografía Partes Blandas",
    "Ecografía Abdominal",
    "Ecografía Tiroides",
    "Ecografía Pélvica"
);

foreach($listado as $item) {
    $pdf->Cell(50, 4, $item, 0, 1, 'L');
    $pdf->SetX(15);
}


// Imágenes adicionales en la barra lateral
$pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
$pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);


$pdf->SetFont('Arial', 'B', 14);
    $pdf->SetXY(70, 10);
    $pdf->Cell(130, 10, ('ECOGRAFÍA TIROIDES'), 0, 1, 'C');

// Información del paciente
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 30);
$pdf->Cell(30, 6, 'PACIENTE:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->nombre . ' ' . $datosPaciente->apellido, 0);

$pdf->SetXY(70, 36);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'DNI:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->documento, 0);

$pdf->SetXY(70, 42);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'EDAD:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->edad . ' años', 0);

$pdf->SetXY(70, 48);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'FECHA:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->fecha, 0);

$pdf->SetXY(70, 54);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'MÉDICO:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->codigo_doctor, 0);

// MOTIVO
$pdf->SetXY(70, 60);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'MOTIVO DE EXAMEN:', 0, 1);
$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 67);
$pdf->MultiCell(130, 5, $datosecografia->motivo, 0);

// TIROIDES
$pdf->SetXY(70, 80);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'TIROIDES:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 87);
$pdf->MultiCell(130, 5, $datosecografia->descripcionTiroides, 0);

// Lóbulos y Istmo
$pdf->SetXY(70, 102);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Lóbulo Derecho:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->lobuloDerecho, 0);

$pdf->SetXY(70, 109);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Lóbulo Izquierdo:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->lobuloIzquierdo, 0);

$pdf->SetXY(70, 116);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Istmo:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->istmo, 0);

// Estructuras y Glandulas
$pdf->SetXY(70, 123);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'ESTRUCTURAS ADYACENTES:', 0, 1);

$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 130);
$pdf->Cell(50, 6, 'Estructuras Vasculares:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->estructurasVasculares, 0);

$pdf->SetXY(70, 137);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Glándulas Submaxilares:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->glandulasSubmaxilares, 0);

$pdf->SetXY(70, 144);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'Adenopatía Cervicales:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->adenopatiaCervicales, 0);

// Piel y TCSC
$pdf->SetXY(70, 151);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'PIEL Y TCSC:', 0, 1);

$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 158);
$pdf->Cell(50, 6, 'Piel:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $datosecografia->piel, 0);

$pdf->SetXY(70, 165);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(50, 6, 'TCSC:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->MultiCell(80, 6, $datosecografia->tcsc, 0);

// Conclusiones
$pdf->SetXY(70, 180);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'CONCLUSIONES:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 187);
$pdf->MultiCell(130, 5, $datosecografia->conclusiones, 0);

// Sugerencias
$pdf->SetXY(70, 205);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'SUGERENCIAS:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 212);
$pdf->MultiCell(130, 5, $datosecografia->sugerencias, 0);


// Pie de página
     // Borde superior decorativo
     $pdf->SetFillColor(0,24,0); // Verde oscuro
     $pdf->Rect(10, 290, 190, 2, 'F');
 
     // Información de contacto
    // Lado izquierdo - Dirección
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(128,128,128); // Color gris para el texto
    $pdf->SetXY(60, 283);
    $pdf->Cell(100, 5, ('DIRECCIÓN: Av. Salaverry 1402 - Urb. Bancarios'), 0, 0, 'L');

    // Lado derecho - Celular e íconos
    $pdf->SetXY(140, 283);
    $pdf->Cell(30, 5, 'CELULAR: 902720312', 0, 0, 'R');
    
    // Íconos al lado del celular
    $pdf->Image("public/img/theme/facebook.png", 175, 283, 4, 4);
    $pdf->Image("public/img/theme/instagram.png", 182, 283, 4, 4);
    $pdf->Image("public/img/theme/wsp.jpeg", 189, 283, 4, 4);

$pdf->Output('I', 'ecografia_tiroides.pdf');
exit;

}


public function getEcografiaHisterosonografiaPdf($dni) {
    $datosPaciente = $this->Ecografias_model->getDatosPaciente($dni)->result()[0];
    $datosecografia = $this->Ecografias_model->getEcografiaHisterosonografiaPdf($dni)->result()[0];

       //documentar esta linea para que genere el pdf 
       
     // print_r($datosPaciente);
    // echo "<br><br><br><br>";
    //print_r($datosecografia);
    //   

  $this->load->library('PDF_UTF8');
  $pdf = new PDF_UTF8();
  $pdf->AddPage();
  $pdf->SetAutoPageBreak(false);

  // Marca de agua
$pdf->SetAlpha(0.1);
$pdf->Image("public/img/theme/logo.png", 70, 90, 120);
$pdf->SetAlpha(1);

// Barra lateral izquierda con imágenes
$pdf->SetFillColor(230,230,230);
$pdf->Rect(10, 5, 50, 277, 'F');

// Imágenes en la barra lateral
$pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
$pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
$pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);

// Lista de ecografías (igual que antes)
$pdf->SetFont('Arial', 'B', 8);
$pdf->SetXY(15, 140);

$listado = array(
    "Ecografía Morfológica",
    "Ecografía Genética",
    "Ecografía Obstétrica",
    "Ecografía Obstétrica Doppler",
    "Ecografía Seguimiento",
    "Ovulatorio",
    "Ecografía Transvaginal",
    "Ecografía Obstétrica – Dopple",
    "Ecografía Gemelar",
    "Ecografía 3D, 4D, 5D",
    "Ecografía de Mamas",
    "",
    "OTRAS ECOGRAFÍAS",
    "Ecografía Partes Blandas",
    "Ecografía Abdominal",
    "Ecografía Tiroides",
    "Ecografía Pélvica"
);

foreach($listado as $item) {
    $pdf->Cell(50, 4, $item, 0, 1, 'L');
    $pdf->SetX(15);
}


// Imágenes adicionales en la barra lateral
$pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
$pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);


$pdf->SetFont('Arial', 'B', 14);
    $pdf->SetXY(70, 10);
    $pdf->Cell(130, 10, ('ECOGRAFÍA HISTEROSONOGRAFIA'), 0, 1, 'C');

// Información del paciente
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetXY(70, 30);
$pdf->Cell(30, 6, 'PACIENTE:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->nombre . ' ' . $datosPaciente->apellido, 0);

$pdf->SetXY(70, 36);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'DNI:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->documento, 0);

$pdf->SetXY(70, 42);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'EDAD:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosPaciente->edad . ' años', 0);

$pdf->SetXY(70, 48);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'FECHA:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->fecha, 0);

$pdf->SetXY(70, 54);
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 6, 'MÉDICO:', 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(100, 6, $datosecografia->codigo_doctor, 0);

// MOTIVO
$pdf->SetXY(70, 65);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'MOTIVO DE EXAMEN:', 0, 1);
$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 70);
$pdf->MultiCell(130, 5, $datosecografia->motivo, 0);

// DESCRIPCIÓN DEL PROCEDIMIENTO
$pdf->SetXY(70, 85);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'DESCRIPCIÓN DEL PROCEDIMIENTO:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 92);
$pdf->MultiCell(130, 5, $datosecografia->descripcionProcedimiento, 0);

// CONCLUSIONES
$pdf->SetXY(70, 130);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'CONCLUSIONES:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 137);
$pdf->MultiCell(130, 5, $datosecografia->conclusiones, 0);

// SUGERENCIAS
$pdf->SetXY(70, 160);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(130, 6, 'SUGERENCIAS:', 0, 1);

$pdf->SetFont('Arial', '', 10);
$pdf->SetXY(70, 167);
$pdf->MultiCell(130, 5, $datosecografia->sugerencias, 0);


// Pie de página
     // Borde superior decorativo
     $pdf->SetFillColor(0,24,0); // Verde oscuro
     $pdf->Rect(10, 290, 190, 2, 'F');
 
     // Información de contacto
    // Lado izquierdo - Dirección
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(128,128,128); // Color gris para el texto
    $pdf->SetXY(60, 283);
    $pdf->Cell(100, 5, ('DIRECCIÓN: Av. Salaverry 1402 - Urb. Bancarios'), 0, 0, 'L');

    // Lado derecho - Celular e íconos
    $pdf->SetXY(140, 283);
    $pdf->Cell(30, 5, 'CELULAR: 902720312', 0, 0, 'R');
    
    // Íconos al lado del celular
    $pdf->Image("public/img/theme/facebook.png", 175, 283, 4, 4);
    $pdf->Image("public/img/theme/instagram.png", 182, 283, 4, 4);
    $pdf->Image("public/img/theme/wsp.jpeg", 189, 283, 4, 4);

    $pdf->Output('I', 'ecografia_histerosonografia.pdf');
    exit;


    }

    public function getEcografiaArterialPdf($dni) {
        $datosPaciente = $this->Ecografias_model->getDatosPaciente($dni)->result()[0];
        $datosecografia = $this->Ecografias_model->getEcografiaArterialPdf($dni)->result()[0];  
    
      $this->load->library('PDF_UTF8');
      $pdf = new PDF_UTF8();
      $pdf->AddPage();
      $pdf->SetAutoPageBreak(false);
    
      // Marca de agua
    $pdf->SetAlpha(0.1);
    $pdf->Image("public/img/theme/logo.png", 70, 90, 120);
    $pdf->SetAlpha(1);
    
    // Barra lateral izquierda con imágenes
    $pdf->SetFillColor(230,230,230);
    $pdf->Rect(10, 5, 50, 277, 'F');
    
    // Imágenes en la barra lateral
    $pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
    $pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
    $pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);
    
    // Lista de ecografías (igual que antes)
    $pdf->SetFont('Arial', 'B', 8);
    $pdf->SetXY(15, 140);
    
    $listado = array(
        "Ecografía Morfológica",
        "Ecografía Genética",
        "Ecografía Obstétrica",
        "Ecografía Obstétrica Doppler",
        "Ecografía Seguimiento",
        "Ovulatorio",
        "Ecografía Transvaginal",
        "Ecografía Obstétrica – Dopple",
        "Ecografía Gemelar",
        "Ecografía 3D, 4D, 5D",
        "Ecografía de Mamas",
        "",
        "OTRAS ECOGRAFÍAS",
        "Ecografía Partes Blandas",
        "Ecografía Abdominal",
        "Ecografía Tiroides",
        "Ecografía Pélvica"
    );
    
    foreach($listado as $item) {
        $pdf->Cell(50, 4, $item, 0, 1, 'L');
        $pdf->SetX(15);
    }
    
    
    // Imágenes adicionales en la barra lateral
    $pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
    $pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);
    
    
    $pdf->SetFont('Arial', 'B', 13);
        $pdf->SetXY(70, 10);
        $pdf->Cell(130, 10, ('ECOGRAFÍA DOPPLER ARTERIAL DE MIEMBROS INFERIORES'), 0, 1, 'C');
    
    // Información del paciente
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->SetXY(70, 30);
    $pdf->Cell(30, 6, 'PACIENTE:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosPaciente->nombre . ' ' . $datosPaciente->apellido, 0);
    
    $pdf->SetXY(70, 36);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'DNI:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosPaciente->documento, 0);
    
    $pdf->SetXY(70, 42);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'EDAD:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosPaciente->edad . ' años', 0);
    
    $pdf->SetXY(70, 48);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'FECHA:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosecografia->fecha, 0);
    
    $pdf->SetXY(70, 54);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'MÉDICO:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosecografia->codigo_doctor, 0);

    // MIEMBRO INFERIOR DERECHO
    $pdf->SetXY(70, 60);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'MIEMBRO INFERIOR DERECHO', 0, 1);
    
    // Descripción del procedimiento derecho
    if (!empty($datosecografia->descripcionProcedimientoDerecho)) {
        $pdf->SetFont('Arial', '', 10);
        $pdf->SetXY(70, 68);
        $pdf->MultiCell(130, 5, $datosecografia->descripcionProcedimientoDerecho, 0);
        $pdf->Ln(3);
    }

    // Tabla para miembro inferior derecho
    $pdf->SetXY(70, 75);
    
    // Encabezados de tabla
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(60, 7, 'ARTERIA', 1, 0, 'C');
    $pdf->Cell(35, 7, 'VPS (cm/seg)', 1, 0, 'C');
    $pdf->Cell(35, 7, 'ONDA', 1, 1, 'C');
    
    // Datos de la tabla
    $pdf->SetFont('Arial', '', 9);
    
    // Femoral Común
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'Femoral Común', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->vps_fc_derecho, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->onda_fc_derecho, 1, 1, 'C');
    
    // Femoral Superficial
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'Femoral Superficial', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->vps_fs_derecho, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->onda_fs_derecho, 1, 1, 'C');
    
    // Poplítea
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'Poplítea', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->vps_poplitea_derecho, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->onda_poplitea_derecho, 1, 1, 'C');
    
    // Tibial Posterior
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'Tibial Posterior', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->vps_tp_derecho, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->onda_tp_derecho, 1, 1, 'C');
    
    // Tibial Anterior
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'Tibial Anterior', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->vps_ta_derecho, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->onda_ta_derecho, 1, 1, 'C');
    
    // Pedia
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'Pedia', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->vps_media_derecho, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->onda_media_derecho, 1, 1, 'C');

    // MIEMBRO INFERIOR IZQUIERDO
    $pdf->SetXY(70, 125);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'MIEMBRO INFERIOR IZQUIERDO', 0, 1);
    
    // Descripción del procedimiento izquierdo
    if (!empty($datosecografia->descripcionProcedimientoIzquierdo)) {
        $pdf->SetFont('Arial', '', 10);
        $pdf->SetXY(70, 132);
        $pdf->MultiCell(130, 5, $datosecografia->descripcionProcedimientoIzquierdo, 0);
        $pdf->Ln(3);
    }

    // Tabla para miembro inferior izquierdo
    $pdf->SetXY(70, 140);
    
    // Encabezados de tabla
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(60, 7, 'ARTERIA', 1, 0, 'C');
    $pdf->Cell(35, 7, 'VPS (cm/seg)', 1, 0, 'C');
    $pdf->Cell(35, 7, 'ONDA', 1, 1, 'C');
    
    // Datos de la tabla
    $pdf->SetFont('Arial', '', 9);
    
    // Femoral Común
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'Femoral Común', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->vps_fc_izquierdo, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->onda_fc_izquierdo, 1, 1, 'C');
    
    // Femoral Superficial
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'Femoral Superficial', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->vps_fs_izquierdo, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->onda_fs_izquierdo, 1, 1, 'C');
    
    // Poplítea
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'Poplítea', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->vps_poplitea_izquierdo, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->onda_poplitea_izquierdo, 1, 1, 'C');
    
    // Tibial Posterior
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'Tibial Posterior', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->vps_tp_izquierdo, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->onda_tp_izquierdo, 1, 1, 'C');
    
    // Tibial Anterior
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'Tibial Anterior', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->vps_ta_izquierdo, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->onda_ta_izquierdo, 1, 1, 'C');
    
    // Pedia
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'Pedia', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->vps_media_izquierdo, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->onda_media_izquierdo, 1, 1, 'C');

    // CONCLUSIONES
    $pdf->SetXY(70, 190);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'CONCLUSIONES:', 0, 1);
    
    // Separamos las conclusiones por líneas y las mostramos con viñetas
    $pdf->SetFont('Arial', '', 10);
    $pdf->SetXY(70, 197);
    $pdf->MultiCell(130, 5, $datosecografia->conclusiones, 0);

    // SUGERENCIAS
    $pdf->SetXY(70, 220);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'SUGERENCIAS:', 0, 1);
    
    $pdf->SetFont('Arial', '', 10);
    $pdf->SetXY(70, 227);
    $pdf->MultiCell(130, 5, $datosecografia->sugerencias, 0);

    // Pie de página
     // Borde superior decorativo
     $pdf->SetFillColor(0,24,0); // Verde oscuro
     $pdf->Rect(10, 290, 190, 2, 'F');
 
     // Información de contacto
    // Lado izquierdo - Dirección
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(128,128,128); // Color gris para el texto
    $pdf->SetXY(60, 283);
    $pdf->Cell(100, 5, ('DIRECCIÓN: Av. Salaverry 1402 - Urb. Bancarios'), 0, 0, 'L');

    // Lado derecho - Celular e íconos
    $pdf->SetXY(140, 283);
    $pdf->Cell(30, 5, 'CELULAR: 902720312', 0, 0, 'R');
    
    // Íconos al lado del celular
    $pdf->Image("public/img/theme/facebook.png", 175, 283, 4, 4);
    $pdf->Image("public/img/theme/instagram.png", 182, 283, 4, 4);
    $pdf->Image("public/img/theme/wsp.jpeg", 189, 283, 4, 4);

    $pdf->Output('I', 'ecografia_arterial.pdf');
    exit;
    
    }

    public function getEcografiaVenosaPdf($dni) {
        $datosPaciente = $this->Ecografias_model->getDatosPaciente($dni)->result()[0];
        $datosecografia = $this->Ecografias_model->getEcografiaVenosaPdf($dni)->result()[0];
    
           //documentar esta linea para que genere el pdf 
           
          //print_r($datosPaciente);
         //echo "<br><br><br><br>";
      // print_r($datosecografia);
        //   
    
      $this->load->library('PDF_UTF8');
      $pdf = new PDF_UTF8();
      $pdf->AddPage();
      $pdf->SetAutoPageBreak(false);
    
      // Marca de agua
    $pdf->SetAlpha(0.1);
    $pdf->Image("public/img/theme/logo.png", 70, 90, 120);
    $pdf->SetAlpha(1);
    
    // Barra lateral izquierda con imágenes
    $pdf->SetFillColor(230,230,230);
    $pdf->Rect(10, 5, 50, 277, 'F');
    
    // Imágenes en la barra lateral
    $pdf->Image("public/img/theme/ecografia_mama.jpg", 12, 20, 46, 30);
    $pdf->Image("public/img/theme/ecografia_renal.jpg", 12, 60, 46, 30);
    $pdf->Image("public/img/theme/ecografia_prostatica.jpg", 12, 100, 46, 30);
    
    // Lista de ecografías (igual que antes)
    $pdf->SetFont('Arial', 'B', 8);
    $pdf->SetXY(15, 140);
    
    $listado = array(
        "Ecografía Morfológica",
        "Ecografía Genética",
        "Ecografía Obstétrica",
        "Ecografía Obstétrica Doppler",
        "Ecografía Seguimiento",
        "Ovulatorio",
        "Ecografía Transvaginal",
        "Ecografía Obstétrica – Dopple",
        "Ecografía Gemelar",
        "Ecografía 3D, 4D, 5D",
        "Ecografía de Mamas",
        "",
        "OTRAS ECOGRAFÍAS",
        "Ecografía Partes Blandas",
        "Ecografía Abdominal",
        "Ecografía Tiroides",
        "Ecografía Pélvica"
    );
    
    foreach($listado as $item) {
        $pdf->Cell(50, 4, $item, 0, 1, 'L');
        $pdf->SetX(15);
    }
    
    
    // Imágenes adicionales en la barra lateral
    $pdf->Image("public/img/theme/ecografia_abdominal.jpg", 12, 210, 46, 30);
    $pdf->Image("public/img/theme/ecografia_tiroides.jpg", 12, 245, 46, 30);
    
    
    $pdf->SetFont('Arial', 'B', 12);
        $pdf->SetXY(70, 10);
        $pdf->Cell(130, 10, ('ECOGRAFÍA DOPPLER VENOSO DE MIEMBROS INFERIORES'), 0, 1, 'C');
    
    // Información del paciente
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->SetXY(70, 30);
    $pdf->Cell(30, 6, 'PACIENTE:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosPaciente->nombre . ' ' . $datosPaciente->apellido, 0);
    
    $pdf->SetXY(70, 36);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'DNI:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosPaciente->documento, 0);
    
    $pdf->SetXY(70, 42);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'EDAD:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosPaciente->edad . ' años', 0);
    
    $pdf->SetXY(70, 48);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'FECHA:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosecografia->fecha, 0);
    
    $pdf->SetXY(70, 54);
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(30, 6, 'MÉDICO:', 0);
    $pdf->SetFont('Arial', '', 10);
    $pdf->Cell(100, 6, $datosecografia->codigo_doctor, 0);

    // MIEMBRO INFERIOR DERECHO
    $pdf->SetXY(70, 60);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'MIEMBRO INFERIOR DERECHO', 0, 1);
    
    // Descripción del procedimiento derecho
    if (!empty($datosecografia->descripcionProcedimientoDerecho)) {
        $pdf->SetFont('Arial', '', 10);
        $pdf->SetXY(70, 65);
        $pdf->MultiCell(130, 5, $datosecografia->descripcionProcedimientoDerecho, 0);
        $pdf->Ln(3);
    }

    // Tabla para miembro inferior derecho
    $pdf->SetXY(70, 75);
    
    // Encabezados de tabla
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(60, 7, 'VENA', 1, 0, 'C');
    $pdf->Cell(35, 7, 'MEDIDA MM', 1, 0, 'C');
    $pdf->Cell(35, 7, 'REFLUJO', 1, 1, 'C');
    
    // Datos de la tabla
    $pdf->SetFont('Arial', '', 9);
    
    // Femoral Común
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'F. COMÚN', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->medida_fc_derecho, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->reflujo_fc_derecho, 1, 1, 'C');
    
    // Safena Mayor Muslo
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'SAFENA MAYOR MUSLO', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->medida_fs_derecho, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->reflujo_fs_derecho, 1, 1, 'C');
    
    // Safena Mayor Pierna
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'SAFENA MAYOR PIERNA', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->medida_tp_derecho, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->reflujo_tp_derecho, 1, 1, 'C');
    
    // Poplítea
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'POPLÍTEA', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->medida_poplitea_derecho, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->reflujo_poplitea_derecho, 1, 1, 'C');
    
    // Safena Menor
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'SAFENA MENOR', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->medida_ta_derecho, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->reflujo_ta_derecho, 1, 1, 'C');
    
    // Perforantes
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'PERFORANTES', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->medida_media_derecho, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->reflujo_media_derecho, 1, 1, 'C');

    // MIEMBRO INFERIOR IZQUIERDO
    $pdf->SetXY(70, 125);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'MIEMBRO INFERIOR IZQUIERDO', 0, 1);
    
    // Descripción del procedimiento izquierdo
    if (!empty($datosecografia->descripcionProcedimientoIzquierdo)) {
        $pdf->SetFont('Arial', '', 10);
        $pdf->SetXY(70, 132);
        $pdf->MultiCell(130, 5, $datosecografia->descripcionProcedimientoIzquierdo, 0);
        $pdf->Ln(3);
    }

    // Tabla para miembro inferior izquierdo
    $pdf->SetXY(70, 145);
    
    // Encabezados de tabla
    $pdf->SetFont('Arial', 'B', 10);
    $pdf->Cell(60, 7, 'VENA', 1, 0, 'C');
    $pdf->Cell(35, 7, 'MEDIDA MM', 1, 0, 'C');
    $pdf->Cell(35, 7, 'REFLUJO', 1, 1, 'C');
    
    // Datos de la tabla
    $pdf->SetFont('Arial', '', 9);
    
    // Femoral Común
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'F. COMÚN', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->medida_fc_izquierdo, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->reflujo_fc_izquierdo, 1, 1, 'C');
    
    // Safena Mayor Muslo
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'SAFENA MAYOR MUSLO', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->medida_fs_izquierdo, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->reflujo_fs_izquierdo, 1, 1, 'C');
    
    // Safena Mayor Pierna
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'SAFENA MAYOR PIERNA', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->medida_tp_izquierdo, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->reflujo_tp_izquierdo, 1, 1, 'C');
    
    // Poplítea
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'POPLÍTEA', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->medida_poplitea_izquierdo, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->reflujo_poplitea_izquierdo, 1, 1, 'C');
    
    // Safena Menor
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'SAFENA MENOR', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->medida_ta_izquierdo, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->reflujo_ta_izquierdo, 1, 1, 'C');
    
    // Perforantes
    $pdf->SetX(70);
    $pdf->Cell(60, 6, 'PERFORANTES', 1, 0, 'L');
    $pdf->Cell(35, 6, $datosecografia->medida_media_izquierdo, 1, 0, 'C');
    $pdf->Cell(35, 6, $datosecografia->reflujo_media_izquierdo, 1, 1, 'C');

    // CONCLUSIONES
    $pdf->SetXY(70, 190);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'CONCLUSIÓN:', 0, 1);

    // Mostramos las conclusiones como texto normal
    $pdf->SetFont('Arial', '', 10);
    $pdf->SetXY(70, 197);
    $pdf->MultiCell(130, 5, $datosecografia->conclusiones, 0);

    
    // SUGERENCIAS
    $pdf->SetXY(70, 220);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(130, 6, 'SUGERENCIAS:', 0, 1);
    
    $pdf->SetFont('Arial', '', 10);
    $pdf->SetXY(70, 227);
    $pdf->MultiCell(130, 5, $datosecografia->sugerencias, 0);

    // Pie de página
     // Borde superior decorativo
     $pdf->SetFillColor(0,24,0); // Verde oscuro
     $pdf->Rect(10, 290, 190, 2, 'F');
 
     // Información de contacto
    // Lado izquierdo - Dirección
    $pdf->SetFont('Arial', '', 9);
    $pdf->SetTextColor(128,128,128); // Color gris para el texto
    $pdf->SetXY(60, 283);
    $pdf->Cell(100, 5, ('DIRECCIÓN: Av. Salaverry 1402 - Urb. Bancarios'), 0, 0, 'L');

    // Lado derecho - Celular e íconos
    $pdf->SetXY(140, 283);
    $pdf->Cell(30, 5, 'CELULAR: 902720312', 0, 0, 'R');
    
    // Íconos al lado del celular
    $pdf->Image("public/img/theme/facebook.png", 175, 283, 4, 4);
    $pdf->Image("public/img/theme/instagram.png", 182, 283, 4, 4);
    $pdf->Image("public/img/theme/wsp.jpeg", 189, 283, 4, 4);

    $pdf->Output('I', 'ecografia_venoso.pdf');
    exit;

    }

}